import './App.css';
import React, {useState,setState,useEffect} from 'react';
import Header from './components/header';
import RegistrationForm from './components/registration';
import registerService from './services/register';
import CourseForm from './components/courseRegistration';
import Exit from './components/exit'
import NavBar from "./components/NavBar";

function App() {

  const [userData, setUserData] = useState(null);
  const [isSubmit, setIsSubmit] = useState(true);

  const handleRegister = async (details) => {
    // try {
      const userObject = await registerService.register(details)
      // console.log(userObject);
      setUserData(userObject);
      // console.log(userObject)
      window.localStorage.setItem('loggedInUser', JSON.stringify(userObject))
      //return userData;
    // }catch (exception){
    //   setUserData(null)
    //   console.log("Error while logging in")
    // }
  };

  const handleSubmit = ()=>{
    setIsSubmit(false)
  }

  // Effect Hook that parses the local storage for 'loggedInUser' and sets the "user" state if a valid match is found
  // This enables user to login automatically without having to type in the credentials. Caching the login if you will.
  useEffect(() => {
    const loggedInUser = window.localStorage.getItem('loggedInUser')
    if (loggedInUser)
      setUserData(JSON.parse(loggedInUser))
  }, [])
  return (
    <div className="App">
      {
        userData===null && isSubmit &&
        <Header />

      }
      {
          userData === null && isSubmit &&
          <RegistrationForm startRegister={handleRegister}/>
      }

      {
        /* Show NavBar when login has happened */
          userData !== null &&
          <NavBar userData={userData} setUser={setUserData}/>
      }

      {
        userData !== null && isSubmit &&
        <CourseForm userData={userData} />
      }
      {
        userData!==null && isSubmit &&
        <div>
          <button onClick={handleSubmit}>SUBMIT</button>
        </div>
      }

      {
        userData!==null && isSubmit===false &&
          <Exit userData={userData}/>
      }

    </div>
  );
}

export default App;