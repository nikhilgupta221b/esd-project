import React from "react";



const Exit = ({userData})=>{
    return(
        <div>
            <h1>Courses have been added successfully.</h1>
        </div>
        )
}
export default Exit;
