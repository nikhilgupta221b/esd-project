import React, { useState, setState, useEffect } from 'react'
import { api } from '../util/api'

import '../style.css'

const CourseBar = ({course}) => {
    
    return (
        <div>
            <h2>{ }</h2>
        </div>
    )
}

export default CourseBar